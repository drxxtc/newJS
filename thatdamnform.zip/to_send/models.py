from django.utils import timezone
from django.db import models


class Project(models.Model):
    project_name = models.CharField(max_length=60)
    status = models.CharField(max_length=60, default='in progress')
    created_at = models.DateTimeField(default=timezone.now)
    #updated_at = models.DateTimeField(default=timezone.now)

    def publish(self):
        self.published_date = timezone.now()
        self.save()

    def __str__(self):
        return self.project_name

# Create your models here.
