from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.core import serializers
from . import models
from .forms import ProjectForm

def main(request):
	if request.method == 'POST':
		form = ProjectForm(request.POST)
		form.save()
		return redirect('main')
	print({'projectform': ProjectForm, 'projects': models.Project.objects.all()})
	return render(request, 'main.html', {'projectform': ProjectForm, 'projects': models.Project.objects.all()})

def getList(request):
	projects = models.Project.objects.all()
	return HttpResponse(serializers.serialize('json', projects), content_type='application/json')



# Create your views here.
