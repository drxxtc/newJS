from django import forms
from .models import *
import time, threading

class ProjectForm(forms.ModelForm):

    class Meta:
        model = Project
        fields = ('project_name', 'status', 'created_at')
        widgets = {'status': forms.HiddenInput(), 'created_at': forms.HiddenInput()}
    def updateStatusAfterWhile(self, timeSec, project):
        time.sleep(timeSec)
        project.status = "ready"
        project.save()
    def save(self, commit=True):
        print("---------------------------------------------------------------------------")
        print("ProjectForm/Save")
        project = super(ProjectForm, self).save(commit=False)
        print("self", super(ProjectForm, self))
        print("self", self)
        print("project", project)
        if commit:
            project.save()
        threading.Thread(target = self.updateStatusAfterWhile, args = (3, project, )).start()
        return project
